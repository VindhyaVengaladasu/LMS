package com.libraryms.model;

public class Issue {

}
