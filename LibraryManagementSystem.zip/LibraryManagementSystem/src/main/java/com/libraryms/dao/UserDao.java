package com.libraryms.dao;

import java.util.List;

import com.libraryms.model.User;

public interface UserDao {
	public Integer addUser(User role);
    public Integer updateUser(User role);
    public Integer deleteUser(Integer roleId);
    public User getUserById(Integer id);
    public Integer getUserIdByName(String name);
    public Integer getUserIdByEmailandPass(String email, String pass);
    public List<User> getAllUser();
}
