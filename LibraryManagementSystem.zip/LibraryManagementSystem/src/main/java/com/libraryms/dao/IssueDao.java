package com.libraryms.dao;

public interface IssueDao {

}
