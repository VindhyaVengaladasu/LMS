package com.libraryms.dao;

import java.util.List;

import com.libraryms.model.Role;

public interface RoleDao {
	public Integer addRole(Role role);
    public Integer updateRole(Role role);
    public Integer deleteRole(Integer roleId);
    public Role getRoleById(Integer id);
    public Integer getRoleIdByName(String name);
    public List<Role> getAllRole();
}
